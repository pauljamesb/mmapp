﻿// refs
// https://docs.microsoft.com/en-us/aspnet/mvc/overview/getting-started/introduction/adding-a-view

using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MMAppMVC.Data;
using MMAppMVC.Models;





namespace MMAppMVC.Controllers
{
    public class ItemsController : Controller
    {

        private readonly ApplicationDbContext _db;
        public ItemsController(ApplicationDbContext db)
        {
            _db = db;
        }


        public IActionResult Index()
        {
            ViewBag.Message = "Hello";
            ViewBag.TotalAmount = AddAllItems();
            return View(_db.DBItems.ToList());
        }








        // Testing just displaying certain items
        public IActionResult DisplaySelected()
        {
            var myResults = _db.DBItems.Where(x => x.Name == "Petrol").ToList();
            return View(myResults);
        }






        // Testing just displaying certain items
        public IActionResult DisplayIncome()
        {

            // If breaks remember added ToLower
            var myResults = _db.DBItems.Where(x => x.InOut.ToLower() == "income").ToList();
            return View(myResults);
        }









        // Move to services class
        // Services/Service.cs
        // Calculation could go here
        public int AddAllItems()
        {
            var total = 0;
            foreach (var el in _db.DBItems)
            {
                // logic
                total = total + el.Amount;
            }
            return total;
        }


        // Create income items
        public IActionResult CreateIncome()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateIncome(MItem mItem)
        {
            if (ModelState.IsValid)
            {
                _db.Add(mItem);
                await _db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(mItem);
        }





        // Create outgoings items
        public IActionResult CreateOutGoing()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateOutGoing(MItem mItem)
        {
            if (ModelState.IsValid)
            {
                _db.Add(mItem);
                await _db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(mItem);
        }





        // Delete items
        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var itemToDelete = await _db.DBItems.FindAsync(id);
            if (itemToDelete == null)
            {
                return NotFound();
            }

            return View(itemToDelete);
        }


        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            var itemToDelete = await _db.DBItems.FindAsync(id);
            _db.DBItems.Remove(itemToDelete);
            await _db.SaveChangesAsync();
            return RedirectToAction("Index");
        }













        // Add this later
        // Edit
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var itemToEdit = await _db.DBItems.FindAsync(id);

            if (itemToEdit == null)
            {
                return NotFound();
            }

            return View(itemToEdit);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, MItem mItem)
        {
            if (id != mItem.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                _db.Update(mItem);
                await _db.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            return View(mItem);
        }


    }
}

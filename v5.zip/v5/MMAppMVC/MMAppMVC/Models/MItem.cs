﻿using System;
namespace MMAppMVC.Models
{
    public class MItem
    {
        public Guid Id { get; set; }
        public DateTime Date { get; set; }
        public string Name { get; set; }
        public string Essential { get; set; }
        public string ReOccuring { get; set; }
        public int Amount { get; set; }
        public string InOut { get; set; }
    }
}

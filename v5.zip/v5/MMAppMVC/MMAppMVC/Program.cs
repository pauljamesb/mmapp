﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

using MMAppMVC.Data;


// https://dotnetthoughts.net/seed-database-in-aspnet-core/
// https://docs.microsoft.com/en-us/azure/app-service/app-service-web-tutorial-dotnetcore-sqldb

// https://github.com/HangfireIO/Hangfire/issues/878

// https://www.hanselman.com/blog/HowToRunBackgroundTasksInASPNET.aspx



namespace MMAppMVC
{
    public class Program
    {

        public static void Main(string[] args)
        {
            CreateWebHostBuilder(args).Build().Run();


            var now = DateTime.Now;

            
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseStartup<Startup>();
    }
}

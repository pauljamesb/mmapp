﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MMAppMVC.Data.Migrations
{
    public partial class RemoveItemTest : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "NewF",
                table: "DBItems");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "NewF",
                table: "DBItems",
                nullable: true);
        }
    }
}

﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MMAppMVC.Data.Migrations
{
    public partial class AddingInOut : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "InOut",
                table: "DBItems",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "InOut",
                table: "DBItems");
        }
    }
}
